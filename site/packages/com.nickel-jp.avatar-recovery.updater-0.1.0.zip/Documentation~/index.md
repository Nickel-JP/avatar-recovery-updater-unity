# AvatarRecovery Update Notifier

This package checks whether a newer AvatarRecovery version has been published.

The notifier does not perform automatic updates. Add its VPM repository with VCC or ALCOM, then install it in a project that already contains AvatarRecovery.

- Check now: `Tools > Nickel-JP > AvatarRecovery Update Notifier > Check Now`
- Settings: `Tools > Nickel-JP > AvatarRecovery Update Notifier > Settings`

When a new version is available, open the manual update guide and update AvatarRecovery with VCC or ALCOM.

## License

Use and local modification are permitted only for personal, private, or internal projects. Redistribution or integration into another public tool or package requires written permission. The bundled `LICENSE` file contains the controlling terms.
